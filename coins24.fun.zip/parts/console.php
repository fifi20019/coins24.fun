<div id="master-modal" class="master-modal animated bounceIn">
	<div class="console-wrapper">	
		<div class="loader-wrapper">
			<div class="loader">Loading...</div>
		</div>
		<div class="console-generation-item console-generation-item-r-1">
			<img src="img/r-item-1.png" class="resource-select-icon" />
			<div class="console-generation-item-value console-generation-item-value-r-1">0</div>
			<div class="resource-item-label">CoD Points</div>
		</div>
		<div class="console-msg-wrapper animated pulse infinite">
			<div class="console-msg"></div>
		</div>
		<div class="console-loadbar-wrapper">
			<div id="progressBarConsole" class="console-loadbar animated bounceIn"><div></div></div>
		</div>
	</div>
</div>